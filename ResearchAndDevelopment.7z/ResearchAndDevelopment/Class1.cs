﻿using System;

namespace ResearchAndDevelopment
{
    public class Class1
    {
    }
}
